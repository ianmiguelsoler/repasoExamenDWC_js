const imagenes = [
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnT7uyxae8RxFlQ7q3i7sZZvFng17wy4QV6Q&s",
    "https://png.pngtree.com/background/20230524/original/pngtree-sad-pictures-for-desktop-hd-backgrounds-picture-image_2705986.jpg",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSJ_Kd_BiDrjxOWTFTpCLtiZ11Z2d5gem_Kvg&s",
    "https://i.blogs.es/603a33/layer-14/1366_2000.jpeg",
];

export { imagenes };