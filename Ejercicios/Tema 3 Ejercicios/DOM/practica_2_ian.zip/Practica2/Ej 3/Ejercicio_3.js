"use strict";

import { temporizadorocultarDom } from "../../Biblioteca_JS/funciones.js";

//!Ejercicio 3.
//?Solución:
temporizadorocultarDom()

