"use strict";

import { carruselDOM } from "../../Biblioteca_JS/funciones.js";

//!Ejercicio 4.
//?Solución:
carruselDOM()

