"use strict";

import { primosDom } from "../../Biblioteca_JS/funciones.js";

//!Ejercicio 2.
//?Solución:
primosDom()

