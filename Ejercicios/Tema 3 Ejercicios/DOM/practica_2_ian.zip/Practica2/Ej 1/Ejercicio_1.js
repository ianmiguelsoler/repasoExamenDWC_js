"use strict";

import { temporizadorEj1 } from "../../Biblioteca_JS/funciones.js";

//!Ejercicio 1.
//?Solución:
temporizadorEj1()

