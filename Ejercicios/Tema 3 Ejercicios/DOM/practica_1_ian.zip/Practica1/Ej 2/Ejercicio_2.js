"use strict";

import { temporizador } from "../Biblioteca_JS/funciones.js";

//!Ejercicio 2.
//?Solución:
temporizador()

