"use strict";

import { contadorElementosDom } from "../Biblioteca_JS/funciones.js";

//!Ejercicio 1.
//?Solución:
contadorElementosDom()

