"use strict";
import { quijoteFrases } from "../Biblioteca_JS/quijoteFrases.js";



//!-------------------------------Ejercicio 1-----------------------------------
//* Funciones
//Función que se utiliza para realizar un conteo de las etiquetas html del documento.

const contadorElementosDom = () =>{

  var parrafos = document.getElementsByTagName("p"); 
  var infoDiv = document.getElementById("info"); // Selecciona el div con id info.
  
  // Función flecha para agregar texto al div.
  const agregarTextoAlDiv = (texto) => {
    const parrafo = document.createElement("p"); // Crea un nuevo párrafo.
    parrafo.textContent = texto; // Asigna el texto.
    infoDiv.appendChild(parrafo); // Agrega el párrafo al div.
  }
  
  agregarTextoAlDiv(`El número de párrafos encontrados son => ${parrafos.length}`);
  
  //Al tener la propiedad innerHTML podemos mostrar hasta las etiquetas del html de manera literal para ver su estructura.
  const segundoParrafoHTML = parrafos[1].innerHTML;
  agregarTextoAlDiv(`El segundo párrafo de la página se encuentra a continuación:\n ${segundoParrafoHTML}`);
  
  // Selecciona todos los elementos <a> del documento.
  const enlaces = document.querySelectorAll('a');
  
  // Muestra el número total de enlaces encontrados.
  agregarTextoAlDiv(`El número de enlaces encontrados es => ${enlaces.length}`);
  
  // Accede al primer enlace.
  const primerEnlace = enlaces[0];
  const primerEnlaceHref = primerEnlace.getAttribute('href');
  const primerChild = primerEnlace.firstElementChild;
  
  agregarTextoAlDiv(`El primer enlace es => ${primerEnlaceHref}`);
  if (primerChild) {
    agregarTextoAlDiv(`El primer child del primer enlace es => ${primerChild.tagName}`);
  }
  
  // Accede al penúltimo enlace.
  const penultimoEnlace = enlaces[enlaces.length - 2];
  const penultimoEnlaceHref = penultimoEnlace.getAttribute('href');
  agregarTextoAlDiv(`El penúltimo enlace es => ${penultimoEnlaceHref}`);

};




//!-------------------------------Ejercicio 2-----------------------------------

 const temporizador = () =>{
   let temporizadorId = setInterval(() => {
    agregaLista();
  }, 2000);
 };
const agregaLista = () =>{
  // Seleccionamos el primer <ul> en el documento al igual que lo hacemos con los arrays añadiendo [0] para la primera posición.
  var mainLista = document.getElementsByTagName("ul")[0]; 
  //Al menos comprobamos que exista un "ul".
  if(mainLista){
    const lista = document.createElement("li"); 
    let numero = Math.floor(Math.random() * 1000) + 1; //Convertimos el número a entero.
    lista.innerText = numero; 
    mainLista.appendChild(lista);
  } else {
    console.error("No se encontró ninguna lista <ul> en el documento.");
  }
 
};



//!-------------------------------Ejercicio 3-----------------------------------

const temporizadorCani = () =>{
  let temporizadorIdCani = setInterval(() => {
    volverCani();
 }, 2000);
};

//* Funciones
//Función que se le pasa una cadena, cambia varios carácteres y los modifica.
function cadenaCani(cadenaCani) {
  var resultado = "";
  //Hacemos un array recorriendo todo el string carácter a carácter.
  for (let contador = 0; contador < cadenaCani.length; contador++) {
    let caracter = cadenaCani[contador];
    // Si el carácter está en mayúsculas, lo cambiamos a minúsculas.
    if (caracter === caracter.toUpperCase()) {
      if (caracter === "c" || caracter === "C") {
        resultado += "k";
      } else {
        resultado += caracter.toLowerCase();
      }
    }
    // Si está en minúsculas, lo cambiamos a mayúsculas.
    else {
      if (caracter === "c" || caracter === "C") {
        resultado += "k";
      } else {
        resultado += caracter.toUpperCase();
      }
    }
  }
  //Código que randomiza la cantidad de H que se agregaran al final de la frase.
  let cuantasH = Math.random() * 4 + 1;
  for (let contador = 0; contador < cuantasH; contador++) {
    resultado += "H";
  }
  return resultado; // Devolvemos el string modificado.
};


//Como es un array podemos utilizar un math random y cambiar el numero para que escoja una frase u otra.
 const volverCani = () =>{
  var mainCadena = document.getElementsByTagName("tbody")[0]; 
  if(mainCadena){
  let numero = Math.floor(Math.random() * quijoteFrases.length);

    const listatr = document.createElement("tr"); 
    const listatdOriginal = document.createElement("td");
    listatdOriginal.innerText = quijoteFrases[numero]; 
    listatr.appendChild(listatdOriginal);

    // Crear la segunda celda (frase caniada).
    const listatdCani = document.createElement("td");
    listatdCani.innerText = cadenaCani(quijoteFrases[numero]);
    listatr.appendChild(listatdCani);

    // Añadir la fila completa al tbody.
    mainCadena.appendChild(listatr);
  }
  else{
    console.error("No se encontró ninguna etiqueta <tr> en el documento.");
  }
  
 };


//!-------------------------------Ejercicio 4-----------------------------------
 const insertAfter = (nuevoElemento, existenteElemento) =>{

   // Obtenemos el padre del elemento existente.
  const padre = existenteElemento.parentNode;

  if(existenteElemento.nextSibling){
    // Si tiene un siguiente hermano, insertamos el nuevo elemento antes de ese hermano.
    padre.insertBefore(nuevoElemento, existenteElemento.nextSibling);
  } else {
    // Si no tiene un siguiente hermano, lo insertamos al final del padre.
    padre.appendChild(nuevoElemento)
  }
 };

 
//!Exportamos las funciones necesarias para las solución.
export {
  contadorElementosDom,
  temporizador,
  temporizadorCani,
  insertAfter
};
