"use strict";

import { temporizadorCani } from "../Biblioteca_JS/funciones.js";

//!Ejercicio 3.
//?Solución:
temporizadorCani()

